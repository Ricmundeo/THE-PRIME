import threading
import time
import os
import random
import sys

# ===============================
#  Cross-platform ESC listener
# ===============================
if os.name == "nt":  # Windows
    import msvcrt
    def check_esc():
        if msvcrt.kbhit():
            key = msvcrt.getch()
            if key == b'\x1b':  # ESC
                return True
        return False
else:  # Linux / Mac
    import termios, tty, select
    def check_esc():
        dr,dw,de = select.select([sys.stdin], [], [], 0)
        if dr:
            key = sys.stdin.read(1)
            if key == '\x1b':  # ESC
                return True
        return False

# ===============================
# SETTINGS
# ===============================
class Settings:
    def __init__(self):
        self.limit_enabled = False
        self.limit_number = 0
        self.auto_save = False
        self.save_file = "primes.txt"
        self.matrix_speed = 0.02

settings = Settings()

# ===============================
# PRIME GENERATOR
# ===============================
class PrimeGenerator(threading.Thread):
    def run(self):
        global stop_all
        while True:
            if stop_all:
                self.running = False
                time.sleep(0.01)
                continue

            if self.reset_flag:
                with self.lock:
                    self.current = 2
                    self.reset_flag = False

            if self.running:
                if is_prime(self.current):
                    print(f"[PRIME] {self.current}")
            time.sleep(0.00005)

    def start_gen(self):
        self.running = True

    def stop_gen(self):
        self.running = False

    def reset_gen(self):
        self.reset_flag = True

# ===============================
# PRIME CHECK
# ===============================
def is_prime(n):
    if n < 2: return False
    if n % 2 == 0: return n == 2
    i = 3
    while i*i <= n:
        if n % i == 0: return False
        i += 2
    return True

# ===============================
# MATRIX RAIN
# ===============================
class MatrixRain(threading.Thread):
    def __init__(self):
        super().__init__()
        self.running = False

    def run(self):
        global stop_all
        columns = os.get_terminal_size().columns
        while True:
            if stop_all or not self.running:
                time.sleep(0.01)
                continue

            chars = "1234567890!@#$%^&*()qwertyuiopasdfghjklzxcvbnm"
            line = "".join(random.choice(chars) for _ in range(columns))
            print("\033[92m" + line + "\033[0m", end="")
            time.sleep(settings.matrix_speed)


# ===============================
# MENU
# ===============================
def print_menu():
    os.system("cls" if os.name=="nt" else "clear")
    print("""
╔══════════════════════════════════╗
║        ⚡ HACKER PRIME GEN ⚡    ║
╠══════════════════════════════════╣
║ 1) Start generování              ║
║ 2) Stop generování               ║
║ 3) Reset                         ║
║ 4) Nastavení                     ║
║ 5) Matrix Rain                   ║
║ 6) Exit                          ║
╚══════════════════════════════════╝
(ESC zastaví Matrix Rain a PrimeGen)
""")

def settings_menu():
    while True:
        os.system("cls" if os.name=="nt" else "clear")
        print(f"""
╔══════════════════════════════════╗
║            ⚙ SETTINGS ⚙          ║
╠══════════════════════════════════╣
║ Limit zapnut: {settings.limit_enabled}
║ Limit číslo: {settings.limit_number}
║ Auto-save: {settings.auto_save}
║ Soubor: {settings.save_file}
║ Matrix speed: {settings.matrix_speed}
╠══════════════════════════════════╣
║ 1) Přepnout limit                ║
║ 2) Nastavit limit                ║
║ 3) Přepnout auto-save            ║
║ 4) Změnit název souboru          ║
║ 5) Nastavit matrix speed         ║
║ 6) Zpět                          ║
╚══════════════════════════════════╝
""")
        c = input("Vyber → ")
        if c=="1": settings.limit_enabled = not settings.limit_enabled
        elif c=="2":
            try: settings.limit_number = int(input("Nový limit: "))
            except: pass
        elif c=="3": settings.auto_save = not settings.auto_save
        elif c=="4": settings.save_file = input("Nový název: ")
        elif c=="5":
            try: settings.matrix_speed = float(input("Nová rychlost (0.01-0.2): "))
            except: pass
        elif c=="6": break

# ===============================
# MAIN
# ===============================
def main():
    gen = PrimeGenerator()
    gen.daemon = True
    gen.start()

    while True:
        print_menu()
        choice = input("Vyber → ")

        if choice=="1":
            gen.start_gen()
        elif choice=="2":
            gen.stop_gen()
        elif choice=="3":
            gen.reset_gen()
        elif choice=="4":
            settings_menu()
        elif choice=="5":
            os.system("cls" if os.name=="nt" else "clear")
            matrix_rain()
        elif choice=="6":
            os.system("cls" if os.name=="nt" else "clear")
            print("Bye bro ")
            sys.exit()

if __name__=="__main__":
    # Linux needs non-blocking stdin
    if os.name != "nt":
        import tty, termios
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        tty.setcbreak(sys.stdin.fileno())
    try:
        main()
    finally:
        if os.name != "nt":
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
