# THE PRIME
## Thanks for downloading THE PRIME
### Important information
When THE PrimeGen is running, you must type 2 and then enter<br>
If there are any problems, write in issues on this link: https://github.com/Ricmundeo/THE-PRIME
