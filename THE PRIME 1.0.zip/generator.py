import threading
import time

stop_all = False

def is_prime(n):
    if n < 2: return False
    if n % 2 == 0: return n == 2
    i = 3
    while i*i <= n:
        if n % i == 0: return False
        i += 2
    return True

class PrimeGenerator(threading.Thread):
    def __init__(self):
        super().__init__()
        self.running = False
        self.reset_flag = False
        self.current = 2
        self.lock = threading.Lock()

    def run(self):
        global stop_all
        while True:
            if stop_all:
                self.running = False
                time.sleep(0.01)
                continue

            if self.reset_flag:
                with self.lock:
                    self.current = 2
                    self.reset_flag = False

            if self.running:
                if is_prime(self.current):
                    print(f"[PRIME] {self.current}")
                self.current += 1

            time.sleep(0.00005)

    def start_gen(self):
        self.running = True

    def stop_gen(self):
        self.running = False

    def reset_gen(self):
        self.reset_flag = True
