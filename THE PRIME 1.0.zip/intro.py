import pygame
import sys

def run_intro():
    pygame.init()

    WIDTH, HEIGHT = 2000, 1500
    window = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Mandarynki productyonz")

    try:
        logo = pygame.image.load("logo1.png")
    except:
        print("ERROR: logo1.png nenalezen!")
        pygame.quit()
        return

    logo = pygame.transform.scale(logo, (800, 800))
    rect = logo.get_rect(center=(WIDTH//2, HEIGHT//2))

    clock = pygame.time.Clock()

    def fade_in(surface, image, rect, speed=16):
        for alpha in range(0, 256, speed):
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()

            surface.fill((0, 0, 0))
            temp = image.copy()
            temp.set_alpha(alpha)
            surface.blit(temp, rect)
            pygame.display.update()
            clock.tick(60)

    def fade_out(surface, image, rect, speed=10):
        for alpha in range(255, -1, -speed):
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()

            surface.fill((0, 0, 0))
            temp = image.copy()
            temp.set_alpha(alpha)
            surface.blit(temp, rect)
            pygame.display.update()
            clock.tick(60)

    fade_in(window, logo, rect)
    pygame.time.delay(1000)
    fade_out(window, logo, rect)

    pygame.quit()
