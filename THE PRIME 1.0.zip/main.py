import os
import sys
import tty
import termios
import subprocess
import time

from intro import run_intro
from generator import PrimeGenerator
from matrix import start_matrix
from menu import print_menu, settings_menu
from settings import settings
from velkacisla import run_velkacisla

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def open_velkacisla():
    """
    Spustí velkacisla.py v samostatném procesu (GUI Tkinter),
    aby hlavní terminál zůstal ovladatelný.
    """
    path = os.path.join(BASE_DIR, "velkacisla.py")
    if not os.path.exists(path):
        print("ERROR: velkacisla.py nenalezen!")
        return

    try:
        subprocess.Popen([sys.executable, path], cwd=BASE_DIR)
    except Exception as e:
        print("Nepodařilo se spustit velkacisla:", e)


def main_loop():
    gen = PrimeGenerator()
    gen.daemon = True
    gen.start()

    while True:
        print_menu()
        choice = input("Vyber → ").strip()

        if choice == "1":
            gen.start_gen()

        elif choice == "2":
            gen.stop_gen()

        elif choice == "3":
            gen.reset_gen()

        elif choice == "4":
            run_velkacisla()
            input("Stiskni Enter pro návrat do menu...")

        elif choice == "5":
            settings_menu()

        elif choice == "6":
            start_matrix()
            input("Stiskni Enter pro návrat do menu...")

        elif choice == "7":
            print("Goodbye")
            time.sleep(0.2)
            return

        else:
            pass


if __name__ == "__main__":
    fd = None
    old_settings = None
    try:
        if os.name != "nt":
            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            tty.setcbreak(fd)

        run_intro()
        main_loop()

    finally:
        if os.name != "nt" and old_settings is not None and fd is not None:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
