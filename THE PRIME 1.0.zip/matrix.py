
import threading
import time
import os
import random

from settings import settings
from utils import check_esc

class MatrixRain(threading.Thread):
    def __init__(self):
        super().__init__()
        self.running = False
        self._stop = threading.Event()

    def run(self):
        columns = max(20, os.get_terminal_size().columns)
        chars = "1234567890!@#$%^&*()qwertyuiopasdfghjklzxcvbnm"

        while not self._stop.is_set():
            if not self.running:
                time.sleep(0.01)
                continue

            line = "".join(random.choice(chars) for _ in range(columns))
            print("\033[92m" + line + "\033[0m", end="")
            time.sleep(settings.matrix_speed)

    def stop(self):
        self._stop.set()


def start_matrix():
    """
    Spustí matrix rain v samostatném vlákně.
    Kontroluje ESC přes utils.check_esc() a zastaví se.
    """
    rain = MatrixRain()
    rain.running = True
    rain.daemon = True
    rain.start()

    print("Matrix Rain běží... (stiskni ESC pro stop)")
    try:
        while True:
            if check_esc():
                rain.running = False
                rain.stop()
                break
            time.sleep(0.01)
    except KeyboardInterrupt:
        rain.running = False
        rain.stop()
