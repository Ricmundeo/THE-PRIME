#martinova verze
import tkinter as tk
import threading
import queue
import math

running = False
n = 1
pocitadlo = 0
q = queue.Queue()
max_radky = 200
vypis_kazde = 100

def je_prvocislo(x):
    if x < 2:
        return False
    if x % 2 == 0:
        return x == 2
    r = int(math.sqrt(x))
    for i in range(3, r + 1, 2):
        if x % i == 0:
            return False
    return True

def generator():
    global n, running, pocitadlo
    while running:
        cislo = n*n - n + 1
        if je_prvocislo(cislo):
            pocitadlo += 1
            if pocitadlo % vypis_kazde == 0:
                q.put(f"{pocitadlo}. prvočíslo: n={n}, hodnota={cislo}\n")
        n += 1

def start():
    global running
    if not running:
        running = True
        threading.Thread(target=generator, daemon=True).start()

def stop():
    global running
    running = False

def reset():
    global running, n, pocitadlo
    running = False
    n = 1
    pocitadlo = 0
    text.delete(1.0, tk.END)

def update_gui():
    """Bezpečné dávkové čtení fronty a omezení počtu řádků."""
    try:
        while True:
            msg = q.get_nowait()
            text.insert(tk.END, msg)
            radky = int(text.index('end-1c').split('.')[0])
            if radky > max_radky:
                text.delete(1.0, f"{radky - max_radky + 1}.0")
    except queue.Empty:
        pass
    text.see(tk.END)
    root.after(50, update_gui)


root = tk.Tk()
root.title("Generátor n² - n + 1 (stabilní pro pomalý PC)")

frame = tk.Frame(root)
frame.pack(pady=5)

tk.Button(frame, text="Start", width=10, command=start).pack(side=tk.LEFT, padx=5)
tk.Button(frame, text="Stop", width=10, command=stop).pack(side=tk.LEFT, padx=5)
tk.Button(frame, text="Reset", width=10, command=reset).pack(side=tk.LEFT, padx=5)

text = tk.Text(root, width=60, height=25)
text.pack()

update_gui()
root.mainloop()
