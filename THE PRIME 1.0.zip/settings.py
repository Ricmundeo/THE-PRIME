class Settings:
    def __init__(self):
        self.limit_enabled = False
        self.limit_number = 0
        self.auto_save = False
        self.save_file = "primes.txt"
        self.matrix_speed = 0.02

settings = Settings()
