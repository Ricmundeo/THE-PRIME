

import sys
import select

def check_esc():
    """
    Non-blocking check for ESC pressed on stdin.
    Vrací True pokud byl stisknut ESC ('\x1b'), jinak False.
    Safe wrapper - pokud select/read selže, vrátí False.
    """
    try:
        dr, _, _ = select.select([sys.stdin], [], [], 0)
        if dr:
            ch = sys.stdin.read(1)
            return ch == '\x1b'
    except Exception:
        return False
    return False
